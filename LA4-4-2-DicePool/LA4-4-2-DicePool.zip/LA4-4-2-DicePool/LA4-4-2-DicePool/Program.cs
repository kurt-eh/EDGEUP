﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA4_4_2_DicePool
{

    /**
*Many tabletop games use dice for various game mechanics. Dice come in many shapes and sizes, commonly having 4, 6, 8, 10, 12, or 20 sides. Many games require you to gather a set of dice of different sizes and roll them together. Create a program that simulates dice for a tabletop game.

Create a class representing a single die. The constructor should accept an integer indicating how many sides the die has. The class should have a function to simulate rolling the die, returning a random number within the valid range.
Create a class representing a pool of dice. This class should have functions to add or remove a die from the pool. The class should also have a function to roll all the dice in the pool and return the total that was rolled.
*/
    class Program
    {
        static ManyDice die = new ManyDice();
        static Random random = new Random((int)DateTime.Now.Ticks);//bouncing the random around to create timing delays to increase randomness (my pc was running all the random values in the same ms).
        static void Main(string[] args)
        {
            Console.WriteLine("Let's roll some dice!");
            Console.WriteLine("Please enter the number of dice you want to roll in the following format:");
            Console.WriteLine("xdy, where \"x\" is the number of dice you want and \"y\" is how many sides they have.");
            Console.WriteLine("Example: 2d6 is 2 6-sided dice. Perfect for playing Catan! (or Monopoly)");
            Console.WriteLine("There are six kinds of dice you can enter: \nd4, d6, d8, d10, d12, d20\n");            
            PlayDice();
            Console.ReadKey();
        }
        static void PrintCommands()
        {
            Console.WriteLine("Instructions:");
            Console.WriteLine("To add a die, type \"add xdy\" to add x number of y sided dice.");
            Console.WriteLine("To remove a die, type \"remove xdy.\"  to remove x number of y sided dice.");
            Console.WriteLine("Type \"dice\" to see a list of all the dice in the pile.");
            Console.WriteLine("Type \"roll\" to roll all the dice and see the results!");
            Console.WriteLine("Type \"clear\" to clear all the dice and start agin!");
            Console.WriteLine("Type \"commands\" to see the command list again.");
            Console.WriteLine("Type \"exit\" to exit program\n");
        }
        static void PlayDice()
        {
            bool firstTime = true; //bool for functionality that shows the last command.
            int numberOfDice = 1;
            int numberOfSides = 1;
            string command = null;
            do 
            {                
                PrintCommands();
                if (firstTime == false) //reminds user of the last command they entered.
                {
                    switch (command.ToLower())
                    {
                        case "add":
                        case "remove":
                            Console.WriteLine("Last Command: {0} {1}d{2}", command, numberOfDice, numberOfSides);
                            break;
                        case "dice":
                        case "roll":
                        case "clear":
                        case "commands":
                        case "you pressed <enter>.":
                            Console.WriteLine("Last Command: {0}", command);
                            break;
                    }
                }
                firstTime = false;
                Console.WriteLine("Enter your command:"); //requests user input
                string[] instructions = CheckCommand(); //method returns string array with 0=command, 1=#dice, 2=#sides.
                command = instructions[0];
                numberOfDice = int.Parse(instructions[1]);
                numberOfSides = int.Parse(instructions[2]);
                switch (command)
                {
                    case "exit":  //exit program.
                    Console.WriteLine("Thank you, play again, soon!");
                    break;
                    case "add"://adds one or more dice of a given type to the bag.
                        die.AddDie(numberOfDice, numberOfSides);
                        break;
                    case "remove": //removes one or more dice of a given type from the bag.              
                        die.Remove(numberOfDice, numberOfSides);
                        break;
                    case "dice": //display all of the dice in the bag.                              
                        die.Display();
                        break;
                    case "roll": //rolls all dice.                        
                        die.ReRollDice(random);
                        break;
                    case "clear": //empty the dice bag.
                        Console.WriteLine("All dice have been removed from the bag. \nPlease add more dice.");
                        die.Clear();
                        break;
                }               
            } while (true);            
        }
        static string[] CheckCommand() //user enters a command, and program checks entered command against the coded options.
        {   
            bool commandError = false;
            string instructions;
            string errorIs="error";
            string[] checkCommand = {"add", "remove", "dice", "roll", "clear", "commands", "exit" };
            string[] commands = { "commands", "0", "0" };//will return a string array with 0=command 1=#dice 2=#sides
            do // loop to ensure commands will work.
            {
                if (commandError == true)
                {
                    Console.Clear();
                    Console.WriteLine("You had an error in your entry.");
                    Console.WriteLine(errorIs);
                    Console.WriteLine("Please try again.\n");
                    PrintCommands();
                }
                commandError = false;
                instructions = Console.ReadLine().Trim().ToLower();
                string[] words = instructions.Split(' ');
                int numberOfDice;
                int numberOfSides;
                if (!checkCommand.Contains(words[0])) //is it a recognized command.
                {
                    commandError = true;
                    errorIs = "Command not recognized. The list of commands is below:";
                    continue;
                }                
                if ((words[0] == "add" || words[0] =="remove")) //while adding or removing dice
                {
                    if (words.Length != 2 ) //checks if there are extra (or not enough) commands.
                    {
                        errorIs = "You did not imput a proper command. Plesae include a <number>d<number> on the command (ie: 2d6).";
                        commandError = true;
                        continue;
                    }
                    else if (!words[1].Contains("d")) //ensures the dice format has a 'd' to properly split the values.
                    {
                        errorIs = "Please enter the dice in the format: <number>d<number> (ie: 2d6).";
                        commandError = true;
                        continue;
                    }
                    string[] xDy = words[1].Split('d');
                    if (xDy[0] == "" || xDy[1] == "")//checks for accidental <enter>
                    {
                        errorIs = "Please enter the dice in the format: <number>d<number>(ie: 2d6).";
                        commandError = true;
                        continue;
                    }
                    bool checkXdY = int.TryParse(xDy[0], out numberOfDice); //checks if the number of dice is an integer
                    if (checkXdY == false)
                    {
                        errorIs = "Please enter the dice in the format: <number>d<number> (ie: 2d6).";
                        commandError = true;
                        continue;
                    }
                    checkXdY = int.TryParse(xDy[1], out numberOfSides); //checks if the number of sides is an integer.
                    if (checkXdY == false)
                    {
                        errorIs = "Please enter the dice in the format: <number>d<number> (ie: 2d6).";
                        commandError = true;
                        continue;
                    }
                    else
                    {
                        int[] checkDice =  { 4, 6, 8, 10, 12, 20 }; 
                        if (!checkDice.Contains(numberOfSides)) //limits entries to the 6 "standard" dice types. 
                        {
                            errorIs = "There are no dice with that number of sides.\nPlease enter:  <number>d<4, 6, 8, 10, 12, or 20> (ie 2d10)";
                            commandError = true;
                            continue;
                        }                      
                    }
                    commands[1] = Convert.ToString(numberOfDice); //returns a string array with 0=command 1=#dice 2=#sides
                    commands[2] = Convert.ToString(numberOfSides);
                }
                commands[0] = words[0];//all entries have a command, but only add/remove have the command xdy format.
            } while (commandError == true) ; //asks user to re-enter command if there is an error.            
            return commands;//returns a string array with 0=command 1=#dice 2=#sides
        }        
    }    
}
